package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Boosts you forward when you jump while moving. */
public final class LongJump extends Module {
    private final NumberSetting boost = add(new NumberSetting("Boost", 0.9, 0.3, 2.0, 0.05));
    private final NumberSetting height = add(new NumberSetting("Height", 0.5, 0.3, 1.0, 0.05));

    public LongJump() {
        super("LongJump", "Jump much further.", Category.MOVEMENT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null || MoveUtil.inLiquidOrSpecial(p)) return;
        if (!p.isOnGround() || !mc.options.jumpKey.isPressed() || !MoveUtil.isMoving()) return;

        double[] d = MoveUtil.direction(p);
        Vec3d v = p.getVelocity();
        p.setVelocity(d[0] * boost.get(), Math.max(v.y, height.get()), d[1] * boost.get());
    }
}
