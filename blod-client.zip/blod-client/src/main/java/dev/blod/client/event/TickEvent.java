package dev.blod.client.event;

/** Fired at the end of every client tick (20/s). */
public record TickEvent() {}
