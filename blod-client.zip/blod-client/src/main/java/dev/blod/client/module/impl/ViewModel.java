package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.util.math.MatrixStack;

/** Moves / scales the first-person hand and item (HeldItemRendererMixin calls {@link #apply}). */
public final class ViewModel extends Module {
    private final NumberSetting x = add(new NumberSetting("X", 0.0, -1.0, 1.0, 0.05));
    private final NumberSetting y = add(new NumberSetting("Y", 0.0, -1.0, 1.0, 0.05));
    private final NumberSetting z = add(new NumberSetting("Z", 0.0, -1.0, 1.0, 0.05));
    private final NumberSetting scale = add(new NumberSetting("Scale", 1.0, 0.3, 1.5, 0.05));

    public ViewModel() {
        super("ViewModel", "Change where your hand and item are.", Category.RENDER, -1);
    }

    public void apply(MatrixStack m) {
        m.translate((float) x.get(), (float) y.get(), (float) z.get());
        float s = scale.getFloat();
        m.scale(s, s, s);
    }
}
