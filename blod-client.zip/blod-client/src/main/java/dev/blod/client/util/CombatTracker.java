package dev.blod.client.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

/** Remembers the last entity we attacked (used by TargetHud / TargetESP). */
public final class CombatTracker {
    private static LivingEntity last;
    private static long time;

    private CombatTracker() {}

    public static void onAttack(Entity target) {
        if (target instanceof LivingEntity le) { last = le; time = System.currentTimeMillis(); }
    }

    /** The last attacked entity if it was hit within the last 6 seconds and is still alive. */
    public static LivingEntity getLast() {
        if (last == null || last.isRemoved() || !last.isAlive()) return null;
        return System.currentTimeMillis() - time < 6000 ? last : null;
    }
}
