package dev.blod.client.module.impl;

import dev.blod.client.gui.NavigatorScreen;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import org.lwjgl.glfw.GLFW;

/** The module menu. Opens with Right Shift (rebindable inside the Navigator itself). */
public final class NavigatorModule extends Module {
    public final BoolSetting blur = add(new BoolSetting("Blur Background", true));
    public final BoolSetting particles = add(new BoolSetting("Particles", true));

    public NavigatorModule() {
        super("Navigator", "Opens the module menu.", Category.CLIENT, GLFW.GLFW_KEY_RIGHT_SHIFT);
        hideBindMode();
        setListed(false);
    }

    @Override public boolean isToggleable() { return false; }

    @Override
    public void onBindPress(boolean pressed) {
        if (pressed && mc.currentScreen == null) mc.setScreen(new NavigatorScreen());
    }
}
