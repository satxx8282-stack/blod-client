package dev.blod.client.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Flat dark button with a red hover glow, used on the main menu. */
public final class BlodButton extends ButtonWidget {
    private float hover;

    public BlodButton(int x, int y, int w, int h, String label, PressAction onPress) {
        super(x, y, w, h, Text.literal(label), onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        hover = Theme.approach(hover, isHovered() ? 1f : 0f, 0.12f);
        int fill = Theme.lerp(Theme.PANEL, 0xFF2A0A10, hover);
        int border = Theme.lerp(0xFF2A2A2A, Theme.RED, hover);

        RenderUtil.roundedOutline(ctx, getX(), getY(), getWidth(), getHeight(), 4, border, fill);
        ctx.fill(getX() + 1, getY() + 5, getX() + 3, getY() + getHeight() - 5, Theme.alpha(Theme.RED, (int) (255 * hover)));

        int textColor = Theme.lerp(Theme.TEXT, 0xFFFFFFFF, hover);
        var tr = MinecraftClient.getInstance().textRenderer;
        RenderUtil.text(ctx, tr, getMessage(), getX() + (getWidth() - RenderUtil.width(tr, getMessage())) / 2, getY() + (getHeight() - 8) / 2, textColor, true);
    }
}
