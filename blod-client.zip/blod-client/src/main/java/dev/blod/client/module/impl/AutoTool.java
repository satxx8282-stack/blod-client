package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While mining, switches to the hotbar tool that breaks the targeted block fastest. */
public final class AutoTool extends Module {
    private final BoolSetting restore = add(new BoolSetting("Restore Slot", true));
    private int prevSlot = -1;

    public AutoTool() {
        super("AutoTool", "Picks the best tool for the block you mine.", Category.PLAYER, -1);
    }

    @Override protected void onDisable() { back(); }

    private void back() {
        if (mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;

        boolean mining = mc.options.attackKey.isPressed() && mc.crosshairTarget instanceof BlockHitResult hit
                && hit.getType() == HitResult.Type.BLOCK;
        if (!mining) { if (restore.get()) back(); else prevSlot = -1; return; }

        BlockState state = mc.world.getBlockState(((BlockHitResult) mc.crosshairTarget).getBlockPos());
        int best = -1;
        float bestSpeed = 1.0f;
        for (int i = 0; i < 9; i++) {
            float sp = p.getInventory().getStack(i).getMiningSpeedMultiplier(state);
            if (sp > bestSpeed) { bestSpeed = sp; best = i; }
        }
        if (best != -1 && best != p.getInventory().selectedSlot) {
            if (prevSlot == -1) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = best;
        }
    }
}
