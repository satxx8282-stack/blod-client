package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;

/** Maximum brightness. SimpleOptionMixin overrides the gamma value while enabled (your options file stays untouched). */
public final class Fullbright extends Module {
    private final NumberSetting gamma = add(new NumberSetting("Gamma", 12, 2, 15, 1));

    public Fullbright() {
        super("Fullbright", "See clearly in the dark.", Category.RENDER, -1);
    }

    public double gamma() { return gamma.get(); }
}
