package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Keep walking / jumping / sprinting while an inventory-type screen is open (not in text-input screens). */
public final class InventoryMove extends Module {
    public InventoryMove() {
        super("InventoryMove", "Move while your inventory is open.", Category.PLAYER, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.player == null || !(mc.currentScreen instanceof HandledScreen<?>)
                || mc.currentScreen instanceof AnvilScreen || mc.currentScreen instanceof CreativeInventoryScreen) return;

        long window = mc.getWindow().getHandle();
        for (KeyBinding k : new KeyBinding[]{mc.options.forwardKey, mc.options.backKey, mc.options.leftKey,
                mc.options.rightKey, mc.options.jumpKey, mc.options.sprintKey}) {
            InputUtil.Key key = InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey());
            if (key.getCategory() != InputUtil.Type.KEYSYM) continue;
            k.setPressed(InputUtil.isKeyPressed(window, key.getCode()));
        }
    }
}
