package dev.blod.client.module.setting;

public final class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String name, boolean value) { super(name, value); }
    public boolean get() { return getValue(); }
    public void toggle() { setValue(!getValue()); }
}
