package dev.blod.client.module.impl;

import com.mojang.authlib.GameProfile;
import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.UUID;

/** Spawns a client-side dummy player on your position - handy to test KillAura, Hitbox, ESP, TargetHud... */
public final class FakePlayer extends Module {
    private static final int FAKE_ID = -1337;
    private OtherClientPlayerEntity fake;

    public FakePlayer() {
        super("FakePlayer", "Spawns a dummy player to test combat modules.", Category.PLAYER, -1);
    }

    @Override public boolean persistEnabled() { return false; }
    @Override protected boolean canEnable() { return mc.player != null && mc.world != null; }

    @Override
    protected void onEnable() {
        fake = new OtherClientPlayerEntity(mc.world, new GameProfile(UUID.randomUUID(), "Blod_Dummy"));
        fake.copyPositionAndRotation(mc.player);
        fake.setHeadYaw(mc.player.getHeadYaw());
        fake.setId(FAKE_ID);
        mc.world.addEntity(fake);
    }

    @Override
    protected void onDisable() {
        if (mc.world != null) mc.world.removeEntity(FAKE_ID, Entity.RemovalReason.DISCARDED);
        fake = null;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.world == null || mc.player == null) setEnabled(false);
    }
}
