package dev.blod.client.util;

import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Aiming helpers. */
public final class Rotations {
    private Rotations() {}

    /** {yaw, pitch} from one point to another, in Minecraft's convention. */
    public static float[] to(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90f, 90f)};
    }

    /** Point of the box that is closest to the given position (used for range checks and aiming). */
    public static Vec3d closestPoint(Box box, Vec3d pos) {
        return new Vec3d(
                MathHelper.clamp(pos.x, box.minX, box.maxX),
                MathHelper.clamp(pos.y, box.minY, box.maxY),
                MathHelper.clamp(pos.z, box.minZ, box.maxZ));
    }
}
