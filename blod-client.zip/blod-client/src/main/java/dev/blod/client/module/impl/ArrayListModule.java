package dev.blod.client.module.impl;

import dev.blod.client.BlodClient;
import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

/** Right-aligned list of enabled modules, longest first. */
public final class ArrayListModule extends Module {
    private final BoolSetting background = add(new BoolSetting("Background", true));
    private final BoolSetting bar = add(new BoolSetting("Accent Bar", true));
    private final ModeSetting colorMode = add(new ModeSetting("Color", "Wave", "Wave", "Red"));

    public ArrayListModule() {
        super("ArrayList", "Shows all enabled modules on screen.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;

        List<Module> active = BlodClient.modules().all().stream()
                .filter(m -> m.isEnabled() && m.isListed())
                .sorted(Comparator.comparingInt((Module m) -> RenderUtil.width(tr, m.getName())).reversed())
                .toList();

        int screenW = ctx.getScaledWindowWidth();
        int y = 4, i = 0;
        double t = System.currentTimeMillis() / 700.0;

        for (Module m : active) {
            int w = RenderUtil.width(tr, m.getName());
            int x = screenW - w - 7;
            int color = colorMode.is("Wave")
                    ? Theme.lerp(Theme.RED, Theme.DARK_RED, (float) (0.5 + 0.5 * Math.sin(t + i * 0.45)))
                    : Theme.RED;

            if (background.get()) ctx.fill(x - 3, y - 1, screenW - (bar.get() ? 2 : 0), y + 10, 0x99000000);
            if (bar.get()) ctx.fill(screenW - 2, y - 1, screenW, y + 10, color);
            RenderUtil.text(ctx, tr, m.getName(), x, y + 1, color, true);
            y += 11;
            i++;
        }
    }
}
