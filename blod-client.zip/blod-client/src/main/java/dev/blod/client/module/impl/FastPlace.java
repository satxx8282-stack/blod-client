package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.mixin.MinecraftClientAccessor;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import net.minecraft.item.BlockItem;

/** Removes the delay between placing blocks / using items. */
public final class FastPlace extends Module {
    private final BoolSetting blocksOnly = add(new BoolSetting("Blocks Only", true));

    public FastPlace() {
        super("FastPlace", "No delay when placing blocks.", Category.PLAYER, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.player == null) return;
        if (blocksOnly.get() && !(mc.player.getMainHandStack().getItem() instanceof BlockItem)) return;
        ((MinecraftClientAccessor) mc).blod$setItemUseCooldown(0);
    }
}
