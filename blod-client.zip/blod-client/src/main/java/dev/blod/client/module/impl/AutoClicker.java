package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.mixin.MinecraftClientAccessor;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.util.hit.HitResult;

import java.util.concurrent.ThreadLocalRandom;

/** Clicks for you while the attack button is held. Does not click while you are aiming at a block (so mining still works). */
public final class AutoClicker extends Module {
    private final NumberSetting minCps = add(new NumberSetting("Min CPS", 8, 1, 20, 1));
    private final NumberSetting maxCps = add(new NumberSetting("Max CPS", 12, 1, 20, 1));

    private double charge;

    public AutoClicker() {
        super("AutoClicker", "Hold attack to click automatically.", Category.COMBAT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.currentScreen != null || !mc.options.attackKey.isPressed()) { charge = 0; return; }
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) return;

        double lo = Math.min(minCps.get(), maxCps.get()), hi = Math.max(minCps.get(), maxCps.get());
        double cps = lo + (hi - lo) * ThreadLocalRandom.current().nextDouble();
        charge += cps / 20.0;
        if (charge >= 1.0) {
            ((MinecraftClientAccessor) mc).blod$doAttack();
            charge -= 1.0;
            if (charge > 1.0) charge = 0;
        }
    }
}
