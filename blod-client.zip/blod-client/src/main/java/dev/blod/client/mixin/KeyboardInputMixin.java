package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.FreeCam;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While FreeCam is on, the real player receives no movement input (so no movement is produced or sent). */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void blod$freezePlayer(CallbackInfo ci) {
        FreeCam fc = BlodClient.module(FreeCam.class);
        if (fc == null || !fc.isEnabled()) return;
        this.playerInput = new PlayerInput(false, false, false, false, false, false, false);
        this.movementForward = 0f;
        this.movementSideways = 0f;
    }
}
