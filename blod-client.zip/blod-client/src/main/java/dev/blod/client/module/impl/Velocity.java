package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;

/** Reduces knockback. ClientPlayNetworkHandlerMixin scales the velocity packets sent for your player. */
public final class Velocity extends Module {
    public final NumberSetting horizontal = add(new NumberSetting("Horizontal %", 0, 0, 100, 5));
    public final NumberSetting vertical = add(new NumberSetting("Vertical %", 0, 0, 100, 5));

    public Velocity() {
        super("Velocity", "Take less knockback.", Category.COMBAT, -1);
    }
}
