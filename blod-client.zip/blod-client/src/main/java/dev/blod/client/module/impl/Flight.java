package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import org.lwjgl.glfw.GLFW;

/** Creative-style flight using velocity. Jump = up, Sneak = down. "Anti Kick" dips slightly now and then. */
public final class Flight extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.6, 0.1, 3.0, 0.05));
    private final NumberSetting vSpeed = add(new NumberSetting("Vertical Speed", 0.4, 0.1, 2.0, 0.05));
    private final BoolSetting antiKick = add(new BoolSetting("Anti Kick", true));

    private int ticks;

    public Flight() {
        super("Flight", "Fly like in creative mode.", Category.MOVEMENT, GLFW.GLFW_KEY_G);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || p.isFallFlying() || p.hasVehicle()) return;

        double[] d = MoveUtil.direction(p);
        double y = 0;
        if (mc.currentScreen == null) {
            if (mc.options.jumpKey.isPressed()) y += vSpeed.get();
            if (mc.options.sneakKey.isPressed()) y -= vSpeed.get();
        }
        if (antiKick.get() && y == 0 && ++ticks % 30 == 0) y = -0.04;

        p.setVelocity(d[0] * speed.get(), y, d[1] * speed.get());
        p.fallDistance = 0;
    }
}
