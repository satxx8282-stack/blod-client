package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Velocity: scales knockback packets that target the local player. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void blod$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        // The packet handler first runs on the network thread and is re-queued onto the main thread;
        // only act on the main-thread pass so the packet is not lost.
        if (!mc.isOnThread() || mc.player == null) return;

        Velocity v = BlodClient.module(Velocity.class);
        if (v == null || !v.isEnabled() || packet.getEntityId() != mc.player.getId()) return;

        double h = v.horizontal.get() / 100.0, vv = v.vertical.get() / 100.0;
        ci.cancel();
        mc.player.setVelocityClient(packet.getVelocityX() * h, packet.getVelocityY() * vv, packet.getVelocityZ() * h);
    }
}
