package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.gui.Projection;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

/**
 * See entities through walls.
 *  Glow: vanilla outline shader (EntityMixin asks shouldGlow / color).
 *  Box:  2D box drawn on the HUD from the projected hitbox.
 * Friends are green.
 */
public final class ESP extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Glow", "Glow", "Box"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", true));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));
    private final BoolSetting items = add(new BoolSetting("Items", false));

    public ESP() {
        super("ESP", "See entities through walls.", Category.RENDER, -1);
    }

    private boolean valid(Entity e) {
        if (e == mc.player) return false;
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof Monster) return hostile.get();
        if (e instanceof PassiveEntity) return passive.get();
        if (e instanceof ItemEntity) return items.get();
        return false;
    }

    /** Used by EntityMixin (Glow mode only). */
    public boolean shouldGlow(Entity e) { return isEnabled() && mode.is("Glow") && valid(e); }

    /** RGB (no alpha). */
    public int color(Entity e) {
        if (FriendManager.isFriend(e)) return 0x55FF55;
        if (e instanceof PlayerEntity) return 0xC41E3A;
        if (e instanceof Monster) return 0x8B0000;
        if (e instanceof ItemEntity) return 0xFFFFFF;
        return 0xFF6A6A;
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (!mode.is("Box") || mc.world == null) return;
        DrawContext ctx = ev.context();
        for (Entity e : mc.world.getEntities()) {
            if (!valid(e)) continue;
            Box box = e.getBoundingBox().offset(e.getLerpedPos(ev.tickDelta()).subtract(e.getPos()));
            double[] r = Projection.projectBox(box, ev.tickDelta());
            if (r == null) continue;
            int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
            if (x2 - x1 < 2 || y2 - y1 < 2) continue;
            int c = 0xFF000000 | color(e);
            ctx.fill(x1, y1, x2, y2, (c & 0x00FFFFFF) | 0x22000000);
            ctx.drawBorder(x1 - 1, y1 - 1, x2 - x1 + 2, y2 - y1 + 2, 0xFF000000);   // dark outline for contrast
            ctx.drawBorder(x1, y1, x2 - x1, y2 - y1, c);
        }
    }
}
