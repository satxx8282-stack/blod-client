package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Equips the best armor from your inventory (and swaps worn pieces for better ones).
 * Pieces are ranked by material name, so it also works with modded sets named like vanilla ones.
 */
public final class AutoArmor extends Module {
    private static final String[] TYPES = {"helmet", "chestplate", "leggings", "boots"};
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private final NumberSetting delay = add(new NumberSetting("Delay (ticks)", 3, 0, 20, 1));
    private int timer;

    public AutoArmor() {
        super("AutoArmor", "Automatically wears the best armor.", Category.COMBAT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof HandledScreen<?>)) return;
        if (timer-- > 0) return;

        for (int t = 0; t < 4; t++) {
            ItemStack worn = p.getEquippedStack(SLOTS[t]);
            int wornScore = worn.isEmpty() ? -1 : score(worn, TYPES[t]);

            int bestSlot = -1, bestScore = wornScore;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                int sc = s.isEmpty() ? -1 : score(s, TYPES[t]);
                if (sc > bestScore) { bestScore = sc; bestSlot = i; }
            }
            if (bestSlot == -1) continue;

            int syncId = p.playerScreenHandler.syncId;
            if (!worn.isEmpty()) {
                mc.interactionManager.clickSlot(syncId, 5 + t, 0, SlotActionType.QUICK_MOVE, p);   // take the old piece off
            } else {
                int handlerSlot = bestSlot < 9 ? 36 + bestSlot : bestSlot;                          // inventory index -> screen slot
                mc.interactionManager.clickSlot(syncId, handlerSlot, 0, SlotActionType.QUICK_MOVE, p);
            }
            timer = delay.getValue().intValue();
            return;                                                                                 // one action per cycle
        }
    }

    /** -1 = not this armor type, otherwise higher = better. */
    private int score(ItemStack stack, String type) {
        String id = Registries.ITEM.getId(stack.getItem()).getPath();
        if (!id.endsWith("_" + type)) return -1;
        if (id.startsWith("netherite")) return 6;
        if (id.startsWith("diamond")) return 5;
        if (id.startsWith("iron")) return 4;
        if (id.startsWith("chainmail")) return 3;
        if (id.startsWith("golden")) return 2;
        if (id.startsWith("turtle")) return 2;
        return 1;
    }
}
