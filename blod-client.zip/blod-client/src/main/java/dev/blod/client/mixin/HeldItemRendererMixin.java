package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.ViewModel;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** ViewModel: transforms the matrix stack used to draw the first-person hand/item. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
    private MatrixStack blod$viewModel(MatrixStack matrices) {
        ViewModel vm = BlodClient.module(ViewModel.class);
        if (vm != null && vm.isEnabled()) vm.apply(matrices);
        return matrices;
    }
}
