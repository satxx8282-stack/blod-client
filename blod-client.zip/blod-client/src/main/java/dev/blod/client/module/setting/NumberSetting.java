package dev.blod.client.module.setting;

public final class NumberSetting extends Setting<Double> {
    private final double min, max, step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name, value);
        this.min = min; this.max = max; this.step = step;
    }

    public double get() { return getValue(); }
    public float getFloat() { return getValue().floatValue(); }
    public double getMin() { return min; }
    public double getMax() { return max; }

    /** Clamps to [min,max] and snaps to the step size. */
    @Override
    public void setValue(Double v) {
        double c = Math.max(min, Math.min(max, v));
        if (step > 0) c = Math.round(c / step) * step;
        super.setValue(Math.max(min, Math.min(max, c)));
    }

    /** Sets the value from a 0..1 slider fraction. */
    public void setFraction(double f) { setValue(min + (max - min) * Math.max(0, Math.min(1, f))); }
    public double fraction() { return (getValue() - min) / (max - min); }

    public String format() {
        return step >= 1 ? String.valueOf((int) get()) : String.format("%.1f", get());
    }
}
