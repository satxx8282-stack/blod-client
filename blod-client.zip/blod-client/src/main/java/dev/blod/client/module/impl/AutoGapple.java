package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Eats a golden apple from your hotbar when your health drops below the threshold, then switches back. */
public final class AutoGapple extends Module {
    private final NumberSetting health = add(new NumberSetting("Health", 10, 2, 19, 1));

    private int prevSlot = -1, eatTicks, cooldown;

    public AutoGapple() {
        super("AutoGapple", "Eats a golden apple when low on health.", Category.COMBAT, -1);
    }

    @Override protected void onDisable() { finish(); }

    private void finish() {
        mc.options.useKey.setPressed(false);
        if (mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
        eatTicks = 0;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (cooldown > 0) cooldown--;

        if (prevSlot != -1) {                                    // currently eating
            eatTicks++;
            mc.options.useKey.setPressed(true);
            if ((!p.isUsingItem() && eatTicks > 3) || eatTicks > 70) { finish(); cooldown = 6; }
            return;
        }

        if (cooldown > 0 || p.getHealth() > health.get() || p.isUsingItem()) return;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if ((s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE)) && !p.getItemCooldownManager().isCoolingDown(s)) {
                prevSlot = p.getInventory().selectedSlot;
                p.getInventory().selectedSlot = i;
                eatTicks = 0;
                return;
            }
        }
    }
}
