package dev.blod.client.gui;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.NotificationsModule;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Queue of on-screen toasts (drawn by NotificationsModule). */
public final class NotificationManager {
    public record Notif(String text, boolean positive, long created) {}

    /** Set while loading configs so we don't spam toasts. */
    public static boolean silent;

    public static final List<Notif> LIST = new CopyOnWriteArrayList<>();

    private NotificationManager() {}

    public static void push(String text, boolean positive) {
        if (silent) return;
        NotificationsModule m = BlodClient.module(NotificationsModule.class);
        if (m == null || !m.isEnabled()) return;
        LIST.add(new Notif(text, positive, System.currentTimeMillis()));
        while (LIST.size() > 6) LIST.remove(0);
    }
}
