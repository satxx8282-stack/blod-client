package dev.blod.client.event;

import dev.blod.client.BlodClient;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Tiny reflection based event bus.
 * Register an object and every @Subscribe method on it becomes a listener for the
 * event type in its parameter. Modules register on enable / unregister on disable,
 * so disabled modules never receive events.
 */
public final class EventBus {
    private record Listener(Object owner, Method method) {}

    private final Map<Class<?>, List<Listener>> listeners = new ConcurrentHashMap<>();

    public void register(Object owner) {
        for (Class<?> c = owner.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.isAnnotationPresent(Subscribe.class) || m.getParameterCount() != 1) continue;
                m.setAccessible(true);
                listeners.computeIfAbsent(m.getParameterTypes()[0], k -> new CopyOnWriteArrayList<>())
                        .add(new Listener(owner, m));
            }
        }
    }

    public void unregister(Object owner) {
        listeners.values().forEach(list -> list.removeIf(l -> l.owner == owner));
    }

    /** Dispatches the event to all listeners and returns it (so callers can check cancellation). */
    public <T> T post(T event) {
        List<Listener> list = listeners.get(event.getClass());
        if (list == null) return event;
        for (Listener l : list) {
            try {
                l.method.invoke(l.owner, event);
            } catch (Exception ex) {
                BlodClient.LOGGER.error("Error in listener {}#{}", l.owner.getClass().getSimpleName(), l.method.getName(), ex);
            }
        }
        return event;
    }
}
